.class public final Landroid/support/design/widget/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/design/widget/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final bottomNavigationStyle:I = 0x7f04005b

.field public static final floatingActionButtonStyle:I = 0x7f04016e

.field public static final navigationViewStyle:I = 0x7f040298

.field public static final state_collapsed:I = 0x7f04034b

.field public static final state_collapsible:I = 0x7f04034c

.field public static final tabStyle:I = 0x7f04037d

.field public static final textInputStyle:I = 0x7f04039e
